Team Members: 

Bitlingu Sai Kumar (26M0841)
Naresh M (26M2119)

Title: Newsroom Geo-Coverage Analyzer

We Have used PySpark to complete Tasks 1 to 7. we used the RDD API for Task 1 and DataFrames for the remaining tasks.

Run instructions:
To run our code, install Apache Spark with PySpark and a compatible Java version. Unzip newsdata.zip so the JSON article files are directly inside the newsdata folder.

Run from the folder containing assignment4.py:
spark-submit assignment4.py newsdata > output.txt

Replace newsdata with the path to your unzipped data folder if it is elsewhere. The results are saved in output.txt.

Assumptions:
we assumed that each JSON file contains one article with a unique article_id. we have kept article IDs as strings and treated missing or null article bodies as empty text. For Task 7, we have also included articles with no listed places with a distinct place count of zero.

For submission, we will include only assignment4.py and this README in a ZIP or tar.gz archive named with both roll numbers. we will leave out the dataset and output.txt.
